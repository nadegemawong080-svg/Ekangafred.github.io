import json, os, re, secrets, time
from flask import Flask, jsonify, request, session, send_from_directory, abort
from werkzeug.security import check_password_hash
B = os.path.dirname(os.path.abspath(__file__)); DB = os.path.join(B, 'data.json'); UP = os.path.join(B, 'static', 'uploads')
os.makedirs(UP, exist_ok=True)
app = Flask(__name__)
kf = os.path.join(B, 'secret.key')
if not os.path.exists(kf):
    open(kf, 'w').write(secrets.token_hex(32))
app.secret_key = open(kf).read()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', MAX_CONTENT_LENGTH=3 * 1024 * 1024)

def load():
    with open(DB, encoding='utf-8') as f: return json.load(f)
def store(d):
    with open(DB + '.tmp', 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(DB + '.tmp', DB)
def cl(s, n): return str(s or '').strip()[:n]
def url(s):
    s = cl(s, 300); return s if re.match(r'^(https?://|/static/uploads/)', s) else ''
def auth():
    if not session.get('a') or request.headers.get('X-CSRF') != session.get('csrf'): abort(403)

@app.route('/')
def home(): return send_from_directory('static', 'index.html')
@app.route('/admin')
def admin(): return send_from_directory('static', 'admin.html')
@app.route('/api/data')
def data():
    d = load(); d.pop('admin', None); return jsonify(d)
@app.route('/api/me')
def me():
    if session.get('a'): return jsonify(ok=True, csrf=session['csrf'])
    return jsonify(ok=False)
@app.route('/api/login', methods=['POST'])
def login():
    j = request.get_json(silent=True) or {}; a = load().get('admin', {})
    if a and j.get('user') == a.get('user') and check_password_hash(a.get('hash', ''), j.get('password', '')):
        session.clear(); session['a'] = 1; session['csrf'] = secrets.token_hex(16)
        return jsonify(ok=True, csrf=session['csrf'])
    time.sleep(1); return jsonify(ok=False), 401
@app.route('/api/logout', methods=['POST'])
def logout(): session.clear(); return jsonify(ok=True)
@app.route('/api/save', methods=['POST'])
def save():
    auth(); j = request.get_json(silent=True) or {}; d = load(); p = j.get('profile', {})
    d['profile'] = {k: cl(p.get(k), 1500 if k == 'about' else 200) for k in ['name', 'title', 'tagline', 'about', 'email', 'whatsapp']}
    d['services'] = [{'title': cl(s.get('title'), 80), 'desc': cl(s.get('desc'), 400), 'icon': cl(s.get('icon'), 4)} for s in j.get('services', [])[:30] if cl(s.get('title'), 80)]
    d['projects'] = [{'title': cl(x.get('title'), 100), 'desc': cl(x.get('desc'), 800), 'category': cl(x.get('category'), 40) or 'Autre',
        'status': x.get('status') if x.get('status') in ('Terminé', 'En cours', 'Maquette') else 'Terminé', 'link': url(x.get('link')), 'image': url(x.get('image'))}
        for x in j.get('projects', [])[:100] if cl(x.get('title'), 100)]
    store(d); return jsonify(ok=True)
@app.route('/api/upload', methods=['POST'])
def upload():
    auth(); f = request.files.get('file'); ext = (f.filename.rsplit('.', 1)[-1].lower() if f and '.' in f.filename else '')
    if ext not in ('png', 'jpg', 'jpeg', 'webp', 'gif'): abort(400)
    n = secrets.token_hex(8) + '.' + ext; f.save(os.path.join(UP, n)); return jsonify(path='/static/uploads/' + n)
if __name__ == '__main__': app.run(debug=False)
