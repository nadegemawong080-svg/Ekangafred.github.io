# Lancez une fois : python creer_admin.py   (crée votre compte administrateur)
import json, getpass
from werkzeug.security import generate_password_hash
u = input("Identifiant : ").strip(); p = getpass.getpass("Mot de passe (8 caractères min.) : ")
assert u and len(p) >= 8, "Identifiant requis et mot de passe trop court"
d = json.load(open('data.json', encoding='utf-8')); d['admin'] = {'user': u, 'hash': generate_password_hash(p)}
json.dump(d, open('data.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1); print("Compte créé.")
